const express = require('express');


const app = express();

app.set('view engine', 'ejs');
app.use(express.static(__dirname + '/public'));
app.use(express.json());
app.use(express.urlencoded({extended: false}));


const employees = [
    {
        employeeID: "ES001",
        name: "Bernice Gbosi",
        position: "Founder"
    },
    {
        employeeID: "ES012",
        name: "Jethro Kusane",
        position: "Intern"
    },
    {
        employeeID: "ES064",
        name: "Antonio Ceasar",
        position: "Administrator"
    },
    {
        employeeID: "ES078",
        name: "Heliz Cole",
        position: "HR Manager"
    },
    {
        employeeID: "ES453",
        name: "Phil Dogbe",
        position: "Cleaner"
    },
    {
        employeeID: "ES034",
        name: "Helo Ruddiger",
        position: "Financial Manager"
    },
    {
        employeeID: "ES542",
        name: "Hackman Arthur",
        position: "Programmer"
    },
    {
        employeeID: "ES065",
        name: "Bryan Altano",
        position: "CEO"
    }
]


app.get('/', (req, res)=> {

    res.render('landing', {
        employees
    });
});

const port = 8027;
app.listen(port, ()=>{
    console.log(`Server has started on port: ${port}`);
})