# INSTALL PACKAGES
    * express
    * ejs
    * mongodb